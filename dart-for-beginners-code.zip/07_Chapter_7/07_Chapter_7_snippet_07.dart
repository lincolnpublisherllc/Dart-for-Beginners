Sometimes, a function needs to give something back. In that case, you declare its return type (e.g., int, String).
int addNumbers(int a, int b) {
return a + b;
}
