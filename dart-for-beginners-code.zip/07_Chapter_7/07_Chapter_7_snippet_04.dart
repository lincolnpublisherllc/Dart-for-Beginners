void greetUser(String name) {
print('Hello, $name!');
}
