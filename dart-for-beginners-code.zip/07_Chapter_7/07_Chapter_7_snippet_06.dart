Notice how String name in the parentheses acts as a placeholder. Each time you call the function, you can pass in a different value.
