print(square(5)); // should print 25
