void main() {
greet();
}
