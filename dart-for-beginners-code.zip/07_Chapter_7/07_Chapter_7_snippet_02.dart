void greet() {
print('Hello from a function!');
}
Here:
void means the function doesn’t return anything.
greet is the function name.
