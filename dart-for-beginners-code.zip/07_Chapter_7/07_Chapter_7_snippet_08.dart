void main() {
int sum = addNumbers(4, 6);
print('The sum is $sum');
}
