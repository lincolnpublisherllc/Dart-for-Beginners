void main() {
greetUser('Amaka');
greetUser('David');
}
