A return type (what the function gives back).
