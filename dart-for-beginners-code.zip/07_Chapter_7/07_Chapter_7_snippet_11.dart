void main() {
print(fullName('Ada', 'Lovelace'));
}
