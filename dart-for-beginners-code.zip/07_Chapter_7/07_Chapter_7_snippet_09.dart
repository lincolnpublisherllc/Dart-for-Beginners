The return type int tells Dart the function must give back an integer.
