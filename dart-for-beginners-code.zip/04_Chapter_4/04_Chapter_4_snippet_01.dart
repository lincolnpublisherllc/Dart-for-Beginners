void main() {
var name = 'Sarah';
var age = 21;
print(name);
print(age);
}
