print(country);
print(year);
}
