int → whole numbers (e.g., 10, -3, 0).
double → decimal numbers (e.g., 3.14, -7.5).
void main() {
int apples = 5;
double price = 2.75;
print(apples);
print(price);
}
