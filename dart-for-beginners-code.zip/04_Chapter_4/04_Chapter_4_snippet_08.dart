Strings are one of the most common data types. They’re always wrapped in either single (') or double (") quotes.
String greeting = "Hello";
String name = 'Aisha';
print(greeting + ' ' + name);
