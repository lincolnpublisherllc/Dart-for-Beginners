String city = 'Lagos';
int population = 15000000;
double temperature = 29.5;
bool isSunny = true;
String → Text (characters inside quotes).
int → Whole numbers (no decimals).
double → Numbers with decimals.
bool → Boolean values: true or false.
