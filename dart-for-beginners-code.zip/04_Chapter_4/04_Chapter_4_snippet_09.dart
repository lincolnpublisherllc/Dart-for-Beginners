print('$greeting $name');
