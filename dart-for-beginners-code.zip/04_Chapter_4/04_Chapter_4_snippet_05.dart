final → A variable that can be set once, then never reassigned.
const → Like final, but the value must be known at compile time (before the program runs).
