void main() {
final today = 'Thursday';
const pi = 3.14159;
