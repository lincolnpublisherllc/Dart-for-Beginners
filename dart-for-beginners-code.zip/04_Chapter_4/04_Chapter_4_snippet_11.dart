void main() {
bool isEvening = false;
bool isRaining = true;
print(isEvening);
print(isRaining);
}
