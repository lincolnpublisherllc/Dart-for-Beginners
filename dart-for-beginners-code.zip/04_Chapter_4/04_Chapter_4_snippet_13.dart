Print a sentence like:
Do I like ice cream? true
