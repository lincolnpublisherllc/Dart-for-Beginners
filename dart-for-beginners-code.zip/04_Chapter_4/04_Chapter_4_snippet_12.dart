Print them out.
Exercise 2:
