if (age >= 18) {
print('You are an adult.');
}
}
