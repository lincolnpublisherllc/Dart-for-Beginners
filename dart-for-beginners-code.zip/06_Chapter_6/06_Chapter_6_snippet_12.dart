If the score is 50 or above, print “Pass.”
Otherwise, print “Fail.”
