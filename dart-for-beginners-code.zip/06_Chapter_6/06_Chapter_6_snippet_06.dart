if, else if, and else
Sometimes, you have more than two possible outcomes. Dart lets you chain conditions with else if.
void main() {
int score = 75;
