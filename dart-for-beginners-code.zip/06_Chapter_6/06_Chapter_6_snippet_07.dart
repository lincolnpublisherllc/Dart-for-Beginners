if (score >= 90) {
print('Grade: A');
} else if (score >= 75) {
print('Grade: B');
} else if (score >= 60) {
print('Grade: C');
} else {
print('Grade: F');
}
}
