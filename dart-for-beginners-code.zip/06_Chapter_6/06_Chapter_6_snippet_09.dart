if (isMember) {
if (purchases > 2) {
print('You earned a loyalty bonus!');
}
}
}
