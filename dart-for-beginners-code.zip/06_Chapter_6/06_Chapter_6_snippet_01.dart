Conditional statements (if, else if, else)
