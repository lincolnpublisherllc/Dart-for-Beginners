if and else
What if you want something to happen when the condition is false? That’s where else comes in.
void main() {
int age = 15;
