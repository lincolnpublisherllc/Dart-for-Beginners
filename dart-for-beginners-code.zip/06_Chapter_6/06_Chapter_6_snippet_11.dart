if (username == 'admin' && password == '1234') {
print('Login successful!');
} else {
print('Invalid credentials.');
}
}
