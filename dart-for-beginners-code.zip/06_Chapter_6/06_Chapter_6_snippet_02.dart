void main() {
int age = 20;
