void main() {
bool isMember = true;
int purchases = 3;
