Print the result
Loop back to the menu until the user enters q
