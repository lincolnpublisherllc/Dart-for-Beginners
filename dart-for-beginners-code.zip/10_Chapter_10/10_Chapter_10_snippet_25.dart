Hint: import dart:math and use pow(a, b).
Format the result to 2 decimal places for division results.
