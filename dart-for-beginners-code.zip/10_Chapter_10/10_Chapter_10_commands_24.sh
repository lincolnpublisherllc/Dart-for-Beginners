dart run calculator.dart
Sample session
Simple Calculator
------------------
