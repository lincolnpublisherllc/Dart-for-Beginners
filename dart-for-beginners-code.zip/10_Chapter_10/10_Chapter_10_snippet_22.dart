double result;
switch (choice) {
case '+':
result = add(a, b);
break;
case '-':
result = subtract(a, b);
break;
case '*':
result = multiply(a, b);
break;
case '/':
result = divide(a, b);
break;
default:
// Should not reach here because we validated the choice
print('Unexpected error.');
continue;
}
