String readLine(String prompt) {
stdout.write(prompt);
final line = stdin.readLineSync();
return (line ?? '').trim();
}
