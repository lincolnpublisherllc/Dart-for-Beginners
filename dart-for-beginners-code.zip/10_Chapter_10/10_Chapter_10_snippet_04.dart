print "Cannot divide by zero" and continue loop
compute result
print result
print "Goodbye"
