void main() {
print('Simple Calculator');
print('------------------');
