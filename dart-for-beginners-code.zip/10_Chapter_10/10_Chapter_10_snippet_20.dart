final a = readNumber('the first');
final b = readNumber('the second');
