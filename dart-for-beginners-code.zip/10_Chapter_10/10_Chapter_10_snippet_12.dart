double? tryParseDouble(String input) => double.tryParse(input.trim());
