double? tryParseDouble(String input) {
return double.tryParse(input.trim());
}
What this does
