if (!['+', '-', '*', '/'].contains(choice)) {
print('Invalid choice. Please select +, -, *, /, or q.');
continue;
}
