print menu
read operator choice
if choice is 'q': break
