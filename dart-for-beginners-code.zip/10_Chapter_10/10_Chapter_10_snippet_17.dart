final choice = readLine('Your choice: ').toLowerCase();
