print('Result: $result');
}
}
How to run
Save as calculator.dart
In your terminal, run:
