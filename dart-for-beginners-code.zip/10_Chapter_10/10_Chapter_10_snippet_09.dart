double readNumber(String label) {
while (true) {
final input = readLine('Enter $label number: ');
final value = tryParseDouble(input);
if (value != null) return value;
print('That is not a valid number. Try again.');
}
}
