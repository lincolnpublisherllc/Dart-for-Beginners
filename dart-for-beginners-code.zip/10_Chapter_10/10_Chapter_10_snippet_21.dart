if (choice == '/' && b == 0) {
print('Cannot divide by zero. Try a different second number.');
continue;
}
