while (true) {
print('\nChoose an operation:');
print('[+] Add');
print('[-] Subtract');
print('[*] Multiply');
print('[/] Divide');
print('[q] Quit');
