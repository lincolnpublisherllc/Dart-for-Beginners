print "Invalid choice" and continue loop
read first number as string
