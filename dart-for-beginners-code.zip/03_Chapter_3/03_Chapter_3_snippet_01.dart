void main() {
print('Hello, World!');
}
When you run this, the console shows:
Hello, World!
Simple, right? Now let’s break it down.
void: This tells Dart that the function doesn’t return a value. In plain English: “I don’t give anything back.”
