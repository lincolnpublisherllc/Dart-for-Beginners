dart run hello.dart
You should see:
Hello, World!
