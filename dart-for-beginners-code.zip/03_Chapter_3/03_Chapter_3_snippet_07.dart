Notice how each print() statement creates a new line of text.
