void main() {
print('Hello, World!');
print('This is my first Dart program.');
print('I can run multiple lines of code.');
}
