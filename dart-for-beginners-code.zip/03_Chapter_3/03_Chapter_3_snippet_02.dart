print(): A built-in function that shows text in the console. Whatever is inside the parentheses gets displayed.
