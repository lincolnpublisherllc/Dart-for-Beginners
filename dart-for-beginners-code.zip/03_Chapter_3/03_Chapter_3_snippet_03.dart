void main() {
print('Hello, World!');
}
Click Run.
Look at the console output:
Hello, World!
