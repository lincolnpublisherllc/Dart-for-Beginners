void main() {
Car myCar = Car('Toyota', 2020);
myCar.drive();
}
