class Car {
String brand;
int year;
