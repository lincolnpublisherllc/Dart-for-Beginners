void drive() {
print('$brand car from $year is driving.');
}
}
