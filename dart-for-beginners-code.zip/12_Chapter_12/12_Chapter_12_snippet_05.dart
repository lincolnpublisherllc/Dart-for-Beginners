Create a Book class with title, author, and year fields.
