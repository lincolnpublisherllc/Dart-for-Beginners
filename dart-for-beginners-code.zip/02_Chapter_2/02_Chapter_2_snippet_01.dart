void main() {
print('Hello from DartPad!');
}
Click Run.
The output window will display:
Hello from DartPad!
