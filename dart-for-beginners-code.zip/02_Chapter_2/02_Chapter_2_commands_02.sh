brew tap dart-lang/dart
brew install dart
