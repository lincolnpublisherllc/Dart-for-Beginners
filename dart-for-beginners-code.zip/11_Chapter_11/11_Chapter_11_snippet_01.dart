void main() {
print('Hello')
}
Error:
