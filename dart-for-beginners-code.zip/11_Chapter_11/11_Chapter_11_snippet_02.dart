void main() {
if (true) {
int x = 5;
}
print(x); // Error: Undefined name 'x'
}
