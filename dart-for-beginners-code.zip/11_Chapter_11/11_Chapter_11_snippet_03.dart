void main() {
int x;
if (true) {
x = 5;
}
print(x); // Works fine
}
