Dart treats uppercase and lowercase letters as different.
void main() {
String name = 'Ada';
print(Name); // ❌ Undefined name 'Name'
}
