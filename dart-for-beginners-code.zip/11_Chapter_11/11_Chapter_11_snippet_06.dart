void main() {
List<String> colors = ['Red', 'Blue', 'Green'];
print(colors[3]); // ❌ RangeError
}
