for (int i = 0; i < colors.length; i++) {
print(colors[i]);
}
