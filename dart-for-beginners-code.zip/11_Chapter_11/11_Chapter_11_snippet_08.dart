void main() {
int a = 5;
int b = 0;
print(a ~/ b); // ❌ Unhandled exception
}
How to avoid it: Always check before dividing.
if (b != 0) {
print(a ~/ b);
} else {
print('Cannot divide by zero');
}
