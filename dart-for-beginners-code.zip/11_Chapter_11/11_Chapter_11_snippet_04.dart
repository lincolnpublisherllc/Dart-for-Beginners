void main() {
int a = 5;
if (a = 10) {   // ❌ Error
print('Equal');
}
}
Error:
Error: This requires 'bool' but the found type is 'int'.
How to avoid it: Use == when comparing.
if (a == 10) {
print('Equal');
}
