int number = 5; // correct
