void main() {
print(age);
}
Error message:
Error: Undefined name 'age'.
Fix: Declare the variable first.
int age = 20;
print(age);
