int number = 'five';
^^^^^
Error type: A value of type 'String' can’t be assigned...
Cause: You tried to assign a string to an integer variable.
