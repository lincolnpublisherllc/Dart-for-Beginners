void main() {
print('Hello')
}
Error message:
