void main() {
int number = 'five';
}
Error message:
