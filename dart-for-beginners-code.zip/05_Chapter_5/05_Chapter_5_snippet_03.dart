void main() {
int x = 10;
print(x);
}
