print(isSunny && isWeekend); // false
print(isSunny || isWeekend); // true
print(!isSunny);             // false
}
