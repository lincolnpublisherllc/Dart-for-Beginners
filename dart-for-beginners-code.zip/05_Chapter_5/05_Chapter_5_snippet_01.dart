void main() {
int a = 10;
int b = 3;
int result = a + b;
print(result);
}
