Comparison operators check relationships between values. They always return a Boolean (true or false).
Operator
Meaning
