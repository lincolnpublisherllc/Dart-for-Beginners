void main() {
bool isSunny = true;
bool isWeekend = false;
