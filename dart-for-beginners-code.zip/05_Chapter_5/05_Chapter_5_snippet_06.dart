void main() {
int a = 10;
int b = 7;
print(a > b);   // true
print(a == b);  // false
}
