Print the results of a + b, a - b, a * b, a / b, a % b.
Exercise 2:
Check if 10 is greater than 7.
Check if 5 is not equal to 5.
Combine two conditions: isAdult = true, hasTicket = false. Print the result of isAdult && hasTicket.
