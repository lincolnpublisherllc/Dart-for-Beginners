void main() {
print(7 + 2);   // 9
print(7 - 2);   // 5
print(7 * 2);   // 14
print(7 / 2);   // 3.5
print(7 ~/ 2);  // 3
print(7 % 2);   // 1
}
