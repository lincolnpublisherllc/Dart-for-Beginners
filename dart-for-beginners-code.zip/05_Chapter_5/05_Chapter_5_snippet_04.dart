void main() {
int y = 10;
y += 5;
print(y);  // 15
}
