Make decisions with if, else, and loops
Organize logic with functions and parameters
Work with collections using lists, sets, and maps
