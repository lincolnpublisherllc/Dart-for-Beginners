void main() {
print('Hello, Dart!');
}
Console output appears directly below:
Hello, Dart!
File names appear in plain text, for example hello.dart.
