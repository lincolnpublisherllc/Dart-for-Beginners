Print the set and notice that duplicates disappear.
