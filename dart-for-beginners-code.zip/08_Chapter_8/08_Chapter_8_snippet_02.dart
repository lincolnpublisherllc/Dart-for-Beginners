print(fruits[0]); // Apple
print(fruits[2]); // Mango
