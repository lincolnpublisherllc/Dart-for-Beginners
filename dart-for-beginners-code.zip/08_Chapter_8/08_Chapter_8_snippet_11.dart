Print the third movie in the list.
Add a new movie, then remove one.
Exercise 2:
