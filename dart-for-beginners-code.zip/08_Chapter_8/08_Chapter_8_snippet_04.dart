print(animals);
}
