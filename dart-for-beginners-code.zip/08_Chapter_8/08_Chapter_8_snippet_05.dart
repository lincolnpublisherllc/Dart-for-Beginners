void main() {
List<int> numbers = [1, 2, 3, 4];
for (int n in numbers) {
print(n);
}
}
