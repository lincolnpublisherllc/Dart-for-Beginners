void main() {
Set<String> colors = {'Red', 'Blue', 'Green'};
