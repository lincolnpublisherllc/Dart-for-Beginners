void main() {
List<String> animals = ['Dog', 'Cat'];
