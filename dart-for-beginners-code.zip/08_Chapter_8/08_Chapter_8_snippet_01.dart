void main() {
List<String> fruits = ['Apple', 'Banana', 'Mango'];
print(fruits);
}
